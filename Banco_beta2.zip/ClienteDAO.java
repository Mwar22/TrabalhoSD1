package br.com.diego.banco;

public interface ClienteDAO {
	public boolean inserir (Cliente cliente);
	public boolean excluir (Cliente cliente);
	
}
